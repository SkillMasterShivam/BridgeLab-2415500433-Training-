
// // Stack implementation using array 
// class index {
//     int[] arr;
//     int top;
//     int capacity;

//     // Constructor to initialize the stack
//     public index(int size) {
//         arr = new int[size];
//         capacity = size;
//         top = -1;
//     }

//     // Add an element to the stack
//     public void push(int x) {
//         if (isFull()) {
//             System.out.println("Stack Overflow! Cannot push " + x);
//             return;
//         }
//         arr[++top] = x;
//         System.out.println("Pushed: " + x);
//     }

//     // Remove the top element
//     public int pop() {
//         if (isEmpty()) {
//             System.out.println("Stack Underflow!");
//             return -1;
//         }
//         return arr[top--];
//     }

//     // Return the top element without removing it
//     public int peek() {
//         if (!isEmpty()) {
//             return arr[top];
//         }
//         return -1;
//     }

//     public boolean isEmpty() {
//         return top == -1;
//     }

//     public boolean isFull() {
//         return top == capacity - 1;
//     }
// }
