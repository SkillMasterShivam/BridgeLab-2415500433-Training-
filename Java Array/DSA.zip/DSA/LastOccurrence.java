import java.util.Scanner;

public class LastOccurrence {
    public static int findLastOccurrence(int[] arr, int target) {
        int lastIndex = -1;

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                lastIndex = i;  // Update whenever target is found
            }
        }

        return lastIndex;
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=sc.nextInt();
        int[] arr=new int[n];
        System.out.println("Enter the elements of the array:");
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        System.out.println("Enter the target element:");
        int target=sc.nextInt();
        int result = findLastOccurrence(arr, target);
        System.out.println("Last Occurrence Index: " + result);
        sc.close();
    }
}
