import java.util.*;

public class LRVchecker {

    private Map<String, List<Integer>> domains;

    public LRVchecker() {
        domains = new HashMap<>();
    }

    // Add variable with its domain
    public void addVariable(String variable, List<Integer> domain) {
        domains.put(variable, domain);
    }

    // Apply LRV heuristic
    public String selectVariableWithLRV() {
        String selectedVariable = null;    
        int minDomainSize = Integer.MAX_VALUE;

        for (Map.Entry<String, List<Integer>> entry : domains.entrySet()) {
            int domainSize = entry.getValue().size();

            if (domainSize < minDomainSize) {
                minDomainSize = domainSize;
                selectedVariable = entry.getKey();
            }
        }

        return selectedVariable;
    }

    // Test
    public static void main(String[] args) {
        LRVchecker checker = new LRVchecker();

        checker.addVariable("X1", Arrays.asList(1, 2, 3));
        checker.addVariable("X2", Arrays.asList(1));
        checker.addVariable("X3", Arrays.asList(1, 2));

        String result = checker.selectVariableWithLRV();

        System.out.println("Variable selected using LRV: " + result);
    }
}