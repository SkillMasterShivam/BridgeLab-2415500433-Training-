import java.util.*;

public class DistinctElementsInKWindow {

    public static void countDistinct(int[] arr, int k) {

        int n = arr.length;

        if (k > n) {
            System.out.println("Invalid window size");
            return;
        }
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < k; i++) {
            map.put(arr[i], map.getOrDefault(arr[i], 0) + 1);
        }

        System.out.print(map.size() + " ");
        for (int i = k; i < n; i++) {
            int prev = arr[i - k];
            map.put(prev, map.get(prev) - 1);
            if (map.get(prev) == 0) {
                map.remove(prev);
            }
            map.put(arr[i], map.getOrDefault(arr[i], 0) + 1);
            System.out.print(map.size() + " ");
        }
    }
    public static void main(String[] args) {
        int[] arr = {1, 2, 1, 3, 4, 2, 3};
        int k = 4;
        countDistinct(arr, k);
    }
}