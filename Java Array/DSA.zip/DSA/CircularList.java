public class CircularList {

    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    static class CircularLinkedList {
        Node head;

        void insert(int data) {
            Node newNode = new Node(data);

            if (head == null) {
                head = newNode;
                return;
            }

            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }

        void makeCircular() {
            if (head == null)
                return;

            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = head;
        }

        void print(int count) {
            if (head == null)
                return;

            Node temp = head;
            for (int i = 0; i < count; i++) {
                System.out.print(temp.data + " -> ");
                temp = temp.next;
            }
            System.out.println("(back to head...)");
        }
    }

    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();

        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);

        list.makeCircular();
        list.print(10);
    }
}
